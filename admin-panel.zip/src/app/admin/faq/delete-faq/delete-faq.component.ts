import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-faq',
  templateUrl: './delete-faq.component.html',
  styleUrls: ['./delete-faq.component.css']
})
export class DeleteFaqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
