import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-faq',
  templateUrl: './view-faq.component.html',
  styleUrls: ['./view-faq.component.css']
})
export class ViewFaqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
