import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-testimonial',
  templateUrl: './delete-testimonial.component.html',
  styleUrls: ['./delete-testimonial.component.css']
})
export class DeleteTestimonialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
