import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-testimonial',
  templateUrl: './view-testimonial.component.html',
  styleUrls: ['./view-testimonial.component.css']
})
export class ViewTestimonialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
