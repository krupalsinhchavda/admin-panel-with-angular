import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactdata',
  templateUrl: './contactdata.component.html',
  styleUrls: ['./contactdata.component.css']
})
export class ContactdataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
