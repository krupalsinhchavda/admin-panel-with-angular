import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-contactdata',
  templateUrl: './delete-contactdata.component.html',
  styleUrls: ['./delete-contactdata.component.css']
})
export class DeleteContactdataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
