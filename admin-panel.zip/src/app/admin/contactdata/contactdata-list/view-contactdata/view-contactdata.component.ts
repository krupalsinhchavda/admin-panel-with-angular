import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-contactdata',
  templateUrl: './view-contactdata.component.html',
  styleUrls: ['./view-contactdata.component.css']
})
export class ViewContactdataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
