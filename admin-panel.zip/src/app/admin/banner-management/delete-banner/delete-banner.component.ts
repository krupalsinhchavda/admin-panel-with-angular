import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-banner',
  templateUrl: './delete-banner.component.html',
  styleUrls: ['./delete-banner.component.css']
})
export class DeleteBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
