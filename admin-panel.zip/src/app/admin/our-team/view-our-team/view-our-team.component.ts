import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-our-team',
  templateUrl: './view-our-team.component.html',
  styleUrls: ['./view-our-team.component.css']
})
export class ViewOurTeamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
