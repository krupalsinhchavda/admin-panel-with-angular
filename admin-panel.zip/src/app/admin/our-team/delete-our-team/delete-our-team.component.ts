import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-our-team',
  templateUrl: './delete-our-team.component.html',
  styleUrls: ['./delete-our-team.component.css']
})
export class DeleteOurTeamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
