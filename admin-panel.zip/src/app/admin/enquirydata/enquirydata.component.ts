import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enquirydata',
  templateUrl: './enquirydata.component.html',
  styleUrls: ['./enquirydata.component.css']
})
export class EnquirydataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
