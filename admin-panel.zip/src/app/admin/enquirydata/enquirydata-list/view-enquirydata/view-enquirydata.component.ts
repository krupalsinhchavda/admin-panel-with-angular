import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-enquirydata',
  templateUrl: './view-enquirydata.component.html',
  styleUrls: ['./view-enquirydata.component.css']
})
export class ViewEnquirydataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
