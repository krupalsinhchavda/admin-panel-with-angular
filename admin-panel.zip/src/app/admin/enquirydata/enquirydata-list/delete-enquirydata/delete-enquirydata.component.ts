import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-enquirydata',
  templateUrl: './delete-enquirydata.component.html',
  styleUrls: ['./delete-enquirydata.component.css']
})
export class DeleteEnquirydataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
