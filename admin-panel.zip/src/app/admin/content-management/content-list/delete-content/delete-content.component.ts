import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-content',
  templateUrl: './delete-content.component.html',
  styleUrls: ['./delete-content.component.css']
})
export class DeleteContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
