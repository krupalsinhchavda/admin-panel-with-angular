import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-role',
  templateUrl: './delete-role.component.html',
  styleUrls: ['./delete-role.component.css']
})
export class DeleteRoleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
