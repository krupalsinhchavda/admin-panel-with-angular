import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-blog',
  templateUrl: './delete-blog.component.html',
  styleUrls: ['./delete-blog.component.css']
})
export class DeleteBlogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
