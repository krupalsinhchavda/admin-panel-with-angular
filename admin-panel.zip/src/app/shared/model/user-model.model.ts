export interface UserModel {
    email: string
    password: string
}